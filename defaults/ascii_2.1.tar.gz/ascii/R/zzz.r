.onLoad <- function(libname, pkgname) {
  options(asciiType = "asciidoc")
  options(asciiBackend = "asciidoc")
##  Report$accessors(c("file", "format", "open", "backend", "encoding", "options", "cygwin", "title", "author", "email", "date", "objects"))
}
