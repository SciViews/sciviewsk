isMac <- function ()
	(grepl("^mac", .Platform$pkgType))
